from flask import Flask, render_template, jsonify

app = Flask(__name__)

# Sample Product Data
products = [
    {
        "id": 1,
        "name": "Quantum Pro Watch",
        "description": "Next-gen smartwatch with holographic display and 30-day battery.",
        "price": 299.99,
        "category": "Electronics",
        "image": "https://images.unsplash.com/photo-1508685096489-7abac47d33cb?auto=format&fit=crop&q=80&w=800"
    },
    {
        "id": 2,
        "name": "Nebula Soundbar",
        "description": "Immersive 3D audio experience with sleek minimalist design.",
        "price": 149.50,
        "category": "Audio",
        "image": "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&q=80&w=800"
    },
    {
        "id": 3,
        "name": "Zenith Laptop",
        "description": "Ultra-thin powerhouse with OLED screen and carbon fiber chassis.",
        "price": 1299.00,
        "category": "Computing",
        "image": "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&q=80&w=800"
    },
    {
        "id": 4,
        "name": "Aura Smart Lamp",
        "description": "Mood-enhancing lighting controlled by voice and ambient sensors.",
        "price": 79.99,
        "category": "Home",
        "image": "https://images.unsplash.com/photo-1534073828943-f801091bb18c?auto=format&fit=crop&q=80&w=800"
    },
    {
        "id": 5,
        "name": "Vortex VR Headset",
        "description": "Wireless VR with 8K resolution and haptic feedback controllers.",
        "price": 599.00,
        "category": "Gaming",
        "image": "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?auto=format&fit=crop&q=80&w=800"
    },
    {
        "id": 6,
        "name": "Titanium Earbuds",
        "description": "Active noise cancelling with industrial strength and crystal clarity.",
        "price": 189.99,
        "category": "Audio",
        "image": "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=800"
    }
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/products')
def get_products():
    return jsonify(products)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False, port=5001)
