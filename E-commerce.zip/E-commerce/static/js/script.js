document.addEventListener('DOMContentLoaded', () => {
    let products = [];
    let cart = JSON.parse(localStorage.getItem('quantumCart')) || [];

    const productGrid = document.getElementById('productGrid');
    const cartItemsContainer = document.getElementById('cartItems');
    const cartCount = document.getElementById('cartCount');
    const cartTotal = document.getElementById('cartTotal');
    const cartSidebar = document.getElementById('cartSidebar');
    const cartOverlay = document.getElementById('cartOverlay');
    const cartTrigger = document.getElementById('cartTrigger');
    const closeCart = document.getElementById('closeCart');
    const searchInput = document.getElementById('productSearch');
    const sortSelect = document.getElementById('sortOrder');
    const categoryFilter = document.getElementById('categoryFilter');
    const checkoutBtn = document.getElementById('checkoutBtn');

    // Fallback Product Data in case API fails or images don't load
    const fallbackProducts = [
        { id: 1, name: "Quantum Pro Watch", description: "Next-gen smartwatch with holographic display.", price: 299.99, category: "Electronics", color: "#6366f1", image: "https://images.unsplash.com/photo-1508685096489-7abac47d33cb?auto=format&fit=crop&q=80&w=800" },
        { id: 2, name: "Nebula Soundbar", description: "Immersive 3D audio experience.", price: 149.50, category: "Audio", color: "#10b981", image: "https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&q=80&w=800" },
        { id: 3, name: "Zenith Laptop", description: "Ultra-thin powerhouse with OLED screen.", price: 1299.00, category: "Computing", color: "#f59e0b", image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&q=80&w=800" },
        { id: 4, name: "Aura Smart Lamp", description: "Mood-enhancing voice controlled lighting.", price: 79.99, category: "Home", color: "#8b5cf6", image: "https://images.unsplash.com/photo-1534073828943-f801091bb18c?auto=format&fit=crop&q=80&w=800" },
        { id: 5, name: "Vortex VR Headset", description: "8K resolution with haptic feedback.", price: 599.00, category: "Gaming", color: "#ec4899", image: "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?auto=format&fit=crop&q=80&w=800" },
        { id: 6, name: "Titanium Earbuds", description: "Active noise cancelling crystal clarity.", price: 189.99, category: "Audio", color: "#06b6d4", image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&q=80&w=800" }
    ];

    // Fetch Products
    const fetchProducts = async () => {
        try {
            const response = await fetch('/api/products');
            if (!response.ok) throw new Error('API output not OK');
            const data = await response.json();
            products = data.length > 0 ? data : fallbackProducts;
        } catch (error) {
            console.warn('API Error, using fallback data:', error);
            products = fallbackProducts;
        }
        renderProducts(products);
    };

    // Render Products Grid
    const renderProducts = (data) => {
        if (!data || data.length === 0) {
            productGrid.innerHTML = '<div class="loading">No gadgets found matching your search.</div>';
            return;
        }
        productGrid.innerHTML = data.map(product => `
            <div class="product-card">
                <div class="product-image-container" style="background: ${product.color || '#1e293b'}">
                    <img src="${product.image}" alt="${product.name}" class="product-image" onerror="this.style.opacity='0'">
                    <div class="product-placeholder">
                        <span class="placeholder-icon">${product.name.charAt(0)}</span>
                    </div>
                </div>
                <div class="product-info">
                    <span class="product-category">${product.category}</span>
                    <h3>${product.name}</h3>
                    <p class="product-desc">${product.description}</p>
                    <div class="product-price-action">
                        <span class="price">$${product.price.toFixed(2)}</span>
                        <button class="add-to-cart-btn" onclick="addToCart(${product.id})">Add to Cart</button>
                    </div>
                </div>
            </div>
        `).join('');
    };

    // Cart Logic
    window.addToCart = (productId) => {
        const product = products.find(p => p.id === productId);
        if (!product) return;

        const existingItem = cart.find(item => item.id === productId);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...product, quantity: 1 });
        }

        updateCart();
        openCartSidebar();
    };

    window.removeFromCart = (productId) => {
        cart = cart.filter(item => item.id !== productId);
        updateCart();
    };

    window.changeQuantity = (productId, delta) => {
        const item = cart.find(item => item.id === productId);
        if (item) {
            item.quantity += delta;
            if (item.quantity <= 0) {
                removeFromCart(productId);
            } else {
                updateCart();
            }
        }
    };

    const updateCart = () => {
        localStorage.setItem('quantumCart', JSON.stringify(cart));
        const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);
        cartCount.textContent = totalItems;
        renderCartItems();
        const totalAmount = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
        cartTotal.textContent = `$${totalAmount.toFixed(2)}`;
    };

    const renderCartItems = () => {
        if (cart.length === 0) {
            cartItemsContainer.innerHTML = '<p class="empty-msg">Your cart is empty.</p>';
            return;
        }

        cartItemsContainer.innerHTML = cart.map(item => `
            <div class="cart-item">
                <div class="item-img-container" style="background: ${item.color || '#1e293b'}">
                     <img src="${item.image}" alt="${item.name}" class="item-img" onerror="this.style.opacity='0'">
                </div>
                <div class="item-details">
                    <h4>${item.name}</h4>
                    <span class="item-price">$${item.price.toFixed(2)}</span>
                    <div class="item-controls">
                        <button class="qty-btn" onclick="changeQuantity(${item.id}, -1)">-</button>
                        <span class="qty">${item.quantity}</span>
                        <button class="qty-btn" onclick="changeQuantity(${item.id}, 1)">+</button>
                    </div>
                    <button class="remove-item" onclick="removeFromCart(${item.id})">Remove</button>
                </div>
            </div>
        `).join('');
    };

    // Sidebars & Overlay
    const openCartSidebar = () => {
        cartSidebar.classList.add('open');
        cartOverlay.style.display = 'block';
    };

    const closeCartSidebar = () => {
        cartSidebar.classList.remove('open');
        cartOverlay.style.display = 'none';
    };

    cartTrigger.addEventListener('click', openCartSidebar);
    closeCart.addEventListener('click', closeCartSidebar);
    cartOverlay.addEventListener('click', closeCartSidebar);

    // Filter, Search, Sort
    const applyFilters = () => {
        let filtered = [...products];
        const query = searchInput.value.toLowerCase();
        if (query) {
            filtered = filtered.filter(p =>
                p.name.toLowerCase().includes(query) ||
                p.description.toLowerCase().includes(query)
            );
        }
        const category = categoryFilter.value;
        if (category !== 'all') {
            filtered = filtered.filter(p => p.category === category);
        }
        const sort = sortSelect.value;
        if (sort === 'low') {
            filtered.sort((a, b) => a.price - b.price);
        } else if (sort === 'high') {
            filtered.sort((a, b) => b.price - a.price);
        }
        renderProducts(filtered);
    };

    searchInput.addEventListener('input', applyFilters);
    sortSelect.addEventListener('change', applyFilters);
    categoryFilter.addEventListener('change', applyFilters);

    checkoutBtn.addEventListener('click', () => {
        if (cart.length === 0) {
            alert('Your cart is empty!');
            return;
        }
        alert(`Order Placed! Total: ${cartTotal.textContent}. Thank you for shopping at Quantum Store.`);
        cart = [];
        updateCart();
        closeCartSidebar();
    });

    fetchProducts();
    updateCart();
});
