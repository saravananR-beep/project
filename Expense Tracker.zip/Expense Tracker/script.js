/**
 * Expense Tracker Pro - Multi-Period Analytics Engine
 */

class ExpenseTracker {
    constructor() {
        this.transactions = JSON.parse(localStorage.getItem('transactions_v2')) || [];
        this.selectedPeriods = []; // Format: YYYY-MM
        this.chart = null;

        // Bootstrap
        this.cacheElements();
        this.init();
    }

    cacheElements() {
        this.form = document.getElementById('transaction-form');
        this.list = document.getElementById('transaction-list');
        this.periodContainer = document.getElementById('period-selector');
        this.compDisplay = document.getElementById('comparison-display');
        this.toast = document.getElementById('toast');
    }

    init() {
        // Form persistence logic
        document.getElementById('date').valueAsDate = new Date();

        // Listeners
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));

        // Initial Render
        this.refreshAll();
    }

    // --- DATA MANAGEMENT ---

    handleSubmit(e) {
        e.preventDefault();

        const description = document.getElementById('description').value.trim();
        const amount = parseFloat(document.getElementById('amount').value);
        const type = document.getElementById('type').value;
        const category = document.getElementById('category').value;
        const date = document.getElementById('date').value;

        // Validation
        if (!description || !date || isNaN(amount) || amount <= 0) {
            this.showToast("Please provide valid transaction details.");
            return;
        }

        const transaction = {
            id: Date.now(),
            description,
            amount,
            type,
            category,
            date
        };

        this.transactions.push(transaction);
        this.save();
        this.form.reset();
        document.getElementById('date').valueAsDate = new Date();

        this.showToast("Transaction added successfully.");
        this.refreshAll();
    }

    deleteTransaction(id) {
        this.transactions = this.transactions.filter(t => t.id !== id);
        this.save();
        this.showToast("Transaction removed.");
        this.refreshAll();
    }

    save() {
        localStorage.setItem('transactions_v2', JSON.stringify(this.transactions));
    }

    // --- UI RENDERING ---

    refreshAll() {
        this.renderHistory();
        this.updatePeriodSelector();
        this.renderComparison();
    }

    renderHistory() {
        this.list.innerHTML = '';
        const sorted = [...this.transactions].sort((a, b) => new Date(b.date) - new Date(a.date));

        sorted.slice(0, 10).forEach(t => {
            const item = document.createElement('div');
            item.className = 'transaction-item';
            item.innerHTML = `
                <div class="item-info">
                    <span class="title">${t.description}</span>
                    <span class="meta">${t.category} • ${t.date}</span>
                </div>
                <div class="item-amount">
                    <span class="${t.type === 'income' ? 'amt-inc' : 'amt-exp'}">
                        ${t.type === 'income' ? '+' : '-'}$${t.amount.toFixed(2)}
                    </span>
                    <button class="btn-delete" onclick="app.deleteTransaction(${t.id})">&times;</button>
                </div>
            `;
            this.list.appendChild(item);
        });
    }

    updatePeriodSelector() {
        // Group by YYYY-MM
        const periods = [...new Set(this.transactions.map(t => t.date.substring(0, 7)))];
        periods.sort((a, b) => b.localeCompare(a));

        this.periodContainer.innerHTML = '';
        periods.forEach(p => {
            const bubble = document.createElement('div');
            bubble.className = `period-bubble ${this.selectedPeriods.includes(p) ? 'active' : ''}`;
            bubble.innerText = this.formatPeriodLabel(p);
            bubble.onclick = () => this.togglePeriod(p);
            this.periodContainer.appendChild(bubble);
        });
    }

    togglePeriod(period) {
        if (this.selectedPeriods.includes(period)) {
            this.selectedPeriods = this.selectedPeriods.filter(p => p !== period);
        } else {
            this.selectedPeriods.push(period);
        }
        this.renderComparison();
        this.updatePeriodSelector(); // UI update for bubble state
    }

    renderComparison() {
        this.compDisplay.innerHTML = '';
        if (this.selectedPeriods.length === 0) {
            this.compDisplay.innerHTML = '<p class="text-muted">Select months above to compare...</p>';
            this.updateChart({});
            return;
        }

        const statsByPeriod = {};
        const sortedSelected = [...this.selectedPeriods].sort((a, b) => a.localeCompare(b));

        sortedSelected.forEach((p, index) => {
            const periodData = this.transactions.filter(t => t.date.startsWith(p));
            const metrics = periodData.reduce((acc, t) => {
                if (t.type === 'income') acc.income += t.amount;
                else acc.expense += t.amount;
                return acc;
            }, { income: 0, expense: 0 });

            const balance = metrics.income - metrics.expense;
            statsByPeriod[p] = { ...metrics, balance };

            // Trend relative to previous period in selection
            let trendHtml = '';
            if (index > 0) {
                const prev = statsByPeriod[sortedSelected[index - 1]];
                const diff = balance - prev.balance;
                const pct = prev.balance !== 0 ? ((diff / Math.abs(prev.balance)) * 100).toFixed(1) : '100';
                const sign = diff >= 0 ? '+' : '';
                trendHtml = `<div class="trend-badge ${diff >= 0 ? 'trend-up' : 'trend-down'}">${sign}${pct}% vs prev</div>`;
            }

            const card = document.createElement('div');
            card.className = 'comp-card';
            card.innerHTML = `
                <span class="period-label">${this.formatPeriodLabel(p)}</span>
                <div class="comp-stat">
                    <span>Income</span>
                    <strong>$${metrics.income.toFixed(2)}</strong>
                </div>
                <div class="comp-stat">
                    <span>Expenses</span>
                    <strong>$${metrics.expense.toFixed(2)}</strong>
                </div>
                <div class="comp-stat">
                    <span>Balance</span>
                    <strong style="color: ${balance >= 0 ? 'var(--income)' : 'var(--expense)'}">$${balance.toFixed(2)}</strong>
                </div>
                ${trendHtml}
            `;
            this.compDisplay.appendChild(card);
        });

        this.updateChart(statsByPeriod);
    }

    // --- VISUALIZATION ---

    updateChart(data) {
        const ctx = document.getElementById('comp-chart').getContext('2d');
        if (this.chart) this.chart.destroy();

        const labels = Object.keys(data).sort();
        if (labels.length === 0) return;

        this.chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels.map(l => this.formatPeriodLabel(l)),
                datasets: [
                    {
                        label: 'Income',
                        data: labels.map(l => data[l].income),
                        backgroundColor: 'rgba(16, 185, 129, 0.7)',
                        borderRadius: 6
                    },
                    {
                        label: 'Expenses',
                        data: labels.map(l => data[l].expense),
                        backgroundColor: 'rgba(239, 68, 68, 0.7)',
                        borderRadius: 6
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom' }
                },
                scales: {
                    y: { beginAtZero: true, grid: { display: false } },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    // --- HELPERS ---

    formatPeriodLabel(period) {
        const [y, m] = period.split('-');
        const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        return `${months[parseInt(m) - 1]} ${y}`;
    }

    showToast(msg) {
        this.toast.innerText = msg;
        this.toast.classList.remove('hidden');
        setTimeout(() => this.toast.classList.add('hidden'), 3000);
    }
}

// Global instance for inline listeners
const app = new ExpenseTracker();
