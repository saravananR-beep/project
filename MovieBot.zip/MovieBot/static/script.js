/* ═══════════════════════════════════════════════════
   MovieBot — Frontend JavaScript
   Handles chat UI, API calls, theme, and interactions
   ═══════════════════════════════════════════════════ */

"use strict";

// ── DOM Elements ──────────────────────────────────────────────
const chatWindow   = document.getElementById("chat-window");
const userInput    = document.getElementById("user-input");
const sendBtn      = document.getElementById("send-btn");
const themeToggle  = document.getElementById("theme-toggle");
const themeIcon    = themeToggle.querySelector(".theme-icon");
const typingWrapper= document.getElementById("typing-wrapper");
const sidebarToggle= document.getElementById("sidebar-toggle");
const sidebar      = document.getElementById("sidebar");
const charCounter  = document.getElementById("char-counter");
const charList     = document.getElementById("char-list");
const clearBtn     = document.getElementById("btn-clear");

// ── State ─────────────────────────────────────────────────────
let isBotTyping = false;

// ── Initialise ────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
    restoreTheme();
    showWelcome();
    loadCharacterList();
    setupSuggestionChips();
    autoResizeInput();
});

// ── Theme ─────────────────────────────────────────────────────
function restoreTheme() {
    const saved = localStorage.getItem("moviebot-theme") || "dark";
    document.documentElement.setAttribute("data-theme", saved);
    themeIcon.textContent = saved === "dark" ? "☀️" : "🌙";
}

themeToggle.addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme");
    const next    = current === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    themeIcon.textContent = next === "dark" ? "☀️" : "🌙";
    localStorage.setItem("moviebot-theme", next);
});

// ── Sidebar toggle ────────────────────────────────────────────
sidebarToggle.addEventListener("click", () => {
    const isMobile = window.innerWidth <= 768;
    if (isMobile) {
        sidebar.classList.toggle("mobile-open");
    } else {
        sidebar.classList.toggle("collapsed");
    }
});

// Close mobile sidebar when clicking outside
document.addEventListener("click", (e) => {
    if (window.innerWidth <= 768 &&
        sidebar.classList.contains("mobile-open") &&
        !sidebar.contains(e.target) &&
        !sidebarToggle.contains(e.target)) {
        sidebar.classList.remove("mobile-open");
    }
});

// ── Welcome Banner ────────────────────────────────────────────
function showWelcome() {
    const banner = document.createElement("div");
    banner.className = "welcome-banner";
    banner.innerHTML = `
        <div class="welcome-emoji">🎬</div>
        <div class="welcome-title">Welcome to MovieBot!</div>
        <p class="welcome-sub">
            Ask me anything about your favourite movie characters.<br>
            I can tell you about their <b>background</b>, <b>personality</b>,
            <b>actor</b>, <b>movies</b>, and <b>fun facts</b>!
        </p>
    `;
    chatWindow.appendChild(banner);

    // Date divider
    const now = new Date();
    const divider = document.createElement("div");
    divider.className = "date-divider";
    divider.textContent = now.toLocaleDateString(undefined, {
        weekday: "long", month: "short", day: "numeric"
    });
    chatWindow.appendChild(divider);
}

// ── Load character tags ───────────────────────────────────────
async function loadCharacterList() {
    try {
        const res  = await fetch("/characters");
        const data = await res.json();
        charList.innerHTML = "";
        data.characters.forEach(name => {
            const tag = document.createElement("span");
            tag.className = "char-tag";
            tag.textContent = name;
            tag.title = `Ask about ${name}`;
            tag.addEventListener("click", () => {
                sendMessage(`Tell me about ${name}`);
            });
            charList.appendChild(tag);
        });
    } catch {
        charList.innerHTML = "<span class='char-tag'>Unavailable</span>";
    }
}

// ── Suggestion Chips ──────────────────────────────────────────
function setupSuggestionChips() {
    document.querySelectorAll(".chip").forEach(chip => {
        chip.addEventListener("click", () => {
            sendMessage(chip.getAttribute("data-msg"));
        });
    });
}

// ── Input auto-resize & counter ───────────────────────────────
function autoResizeInput() {
    userInput.addEventListener("input", () => {
        userInput.style.height = "auto";
        userInput.style.height = Math.min(userInput.scrollHeight, 140) + "px";
        charCounter.textContent = `${userInput.value.length}/500`;
    });
}

// ── Keyboard shortcuts ────────────────────────────────────────
userInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        handleSend();
    }
});

sendBtn.addEventListener("click", handleSend);
clearBtn.addEventListener("click", clearChat);

// ── Send handler ──────────────────────────────────────────────
function handleSend() {
    const text = userInput.value.trim();
    if (!text || isBotTyping) return;
    sendMessage(text);
}

async function sendMessage(text) {
    if (!text || isBotTyping) return;

    // Clear & reset input
    userInput.value = "";
    userInput.style.height = "auto";
    charCounter.textContent = "0/500";

    // Append user bubble
    appendMessage(text, "user");
    scrollToBottom();

    // Show typing
    showTyping();
    setSendState(true);

    // Small random delay for realism (600–1200ms)
    const delay = 600 + Math.random() * 600;
    try {
        const [res] = await Promise.all([
            fetch("/chat", {
                method : "POST",
                headers: { "Content-Type": "application/json" },
                body   : JSON.stringify({ message: text }),
            }),
            new Promise(r => setTimeout(r, delay))
        ]);

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        hideTyping();
        appendMessage(data.response || "Sorry, something went wrong.", "bot");
    } catch (err) {
        hideTyping();
        appendMessage(
            "⚠️ Oops! I couldn't reach the server. Please try again in a moment.",
            "bot"
        );
        console.error("Chat error:", err);
    } finally {
        setSendState(false);
        scrollToBottom();
        userInput.focus();
    }
}

// ── Append message bubble ─────────────────────────────────────
function appendMessage(html, sender) {
    const row    = document.createElement("div");
    row.className = `message-row ${sender}`;

    const avatar = document.createElement("div");
    avatar.className = `avatar ${sender}-avatar`;
    avatar.textContent = sender === "bot" ? "🎬" : "👤";

    const col = document.createElement("div");
    col.style.display = "flex";
    col.style.flexDirection = "column";

    const bubble = document.createElement("div");
    bubble.className = `bubble ${sender}`;
    bubble.innerHTML = html;

    const time = document.createElement("div");
    time.className = "msg-time";
    time.textContent = formatTime(new Date());

    col.appendChild(bubble);
    col.appendChild(time);

    if (sender === "bot") {
        row.appendChild(avatar);
        row.appendChild(col);
    } else {
        row.appendChild(col);
        row.appendChild(avatar);
    }

    chatWindow.appendChild(row);

    // Remove welcome banner after first message
    const welcome = chatWindow.querySelector(".welcome-banner");
    if (welcome && chatWindow.children.length > 3) {
        welcome.style.opacity = "0";
        welcome.style.transition = "opacity 0.3s";
        setTimeout(() => welcome.remove(), 300);
    }
}

// ── Typing indicator ──────────────────────────────────────────
function showTyping() {
    isBotTyping = true;
    typingWrapper.classList.add("visible");
    scrollToBottom();
}

function hideTyping() {
    isBotTyping = false;
    typingWrapper.classList.remove("visible");
}

// ── UI helpers ────────────────────────────────────────────────
function setSendState(disabled) {
    sendBtn.disabled = disabled;
    userInput.disabled = disabled;
}

function scrollToBottom() {
    requestAnimationFrame(() => {
        chatWindow.scrollTo({ top: chatWindow.scrollHeight, behavior: "smooth" });
    });
}

function formatTime(date) {
    return date.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

// ── Clear chat ────────────────────────────────────────────────
async function clearChat() {
    try {
        await fetch("/clear", { method: "POST" });
    } catch { /* ignore */ }

    chatWindow.innerHTML = "";
    showWelcome();

    const divider = document.createElement("div");
    divider.className = "date-divider";
    divider.textContent = new Date().toLocaleDateString(undefined, {
        weekday: "long", month: "short", day: "numeric"
    });
    chatWindow.appendChild(divider);
}
