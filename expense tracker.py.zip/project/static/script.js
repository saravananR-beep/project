// DOM Elements
const balanceEl = document.getElementById('balance');
const incomeTotalEl = document.getElementById('income-total');
const expenseTotalEl = document.getElementById('expense-total');
const listEl = document.getElementById('transaction-list');
const formEl = document.getElementById('transaction-form');
const descriptionInput = document.getElementById('description');
const amountInput = document.getElementById('amount');
const typeInput = document.getElementById('type');
const categoryInput = document.getElementById('category');
const dateInput = document.getElementById('date');

// Set default date to today
dateInput.valueAsDate = new Date();

// State Management
let transactions = [];
let chart = null;

// Cyber-Futuristic Colors
const COLORS = {
    cyan: '#06B6D4',
    blue: '#3B82F6',
    purple: '#8B5CF6',
    text: '#F9FAFB',
    muted: '#9CA3AF',
    bg: '#111827',
    error: '#EF4444'
};

/**
 * Initialize the application
 */
async function init() {
    try {
        const response = await fetch('/api/transactions');
        transactions = await response.json();

        renderList();
        updateTotals();
        updateChart();
    } catch (error) {
        console.error('CORE_CONNECTION_ERROR:', error);
    }
}

/**
 * Render the transaction list
 */
function renderList() {
    listEl.innerHTML = '';

    if (transactions.length === 0) {
        listEl.innerHTML = '<div class="empty-state">DATA_STREAM_EMPTY: INITIALIZE_TRANSACTION_SEQUENCE</div>';
        return;
    }

    transactions.forEach(addTransactionDOM);
}

/**
 * Add a transaction to the UI list
 */
function addTransactionDOM(transaction) {
    const sign = transaction.type === 'income' ? '+' : '-';
    const item = document.createElement('li');
    item.classList.add('transaction-item');

    item.innerHTML = `
        <div class="transaction-info">
            <span class="transaction-description">${transaction.description}</span>
            <span class="transaction-meta">${transaction.category.toUpperCase()} • ${transaction.date}</span>
        </div>
        <div class="transaction-amount-container">
            <span class="transaction-amount ${transaction.type === 'income' ? 'plus' : 'minus'}">
                ${sign}$${Math.abs(transaction.amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <button class="delete-btn" onclick="removeTransaction(${transaction.id})" aria-label="EJECT">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18m-2 0v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6m3 0V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>
            </button>
        </div>
    `;

    listEl.appendChild(item);
}

/**
 * Calculate and update totals
 */
function updateTotals() {
    const amounts = transactions.map(t => t.type === 'income' ? t.amount : -t.amount);

    const total = amounts.reduce((acc, item) => (acc += item), 0);
    const income = amounts.filter(item => item > 0).reduce((acc, item) => (acc += item), 0);
    const expense = Math.abs(amounts.filter(item => item < 0).reduce((acc, item) => (acc += item), 0));

    balanceEl.innerText = `$${total.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    incomeTotalEl.innerText = `$${income.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    expenseTotalEl.innerText = `$${expense.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

    balanceEl.style.color = total >= 0 ? COLORS.text : COLORS.error;
}

/**
 * Update the category-based chart
 */
function updateChart() {
    const canvas = document.getElementById('expense-chart');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');

    if (chart) chart.destroy();

    const expenseTransactions = transactions.filter(t => t.type === 'expense');

    if (transactions.length === 0 || expenseTransactions.length === 0) {
        return;
    }

    const expenseData = expenseTransactions.reduce((acc, t) => {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
        return acc;
    }, {});

    const labels = Object.keys(expenseData);
    const data = Object.values(expenseData);

    const palette = [
        COLORS.cyan,
        COLORS.blue,
        COLORS.purple,
        '#F472B6',
        '#FBBF24',
        '#34D399'
    ];

    chart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: palette.slice(0, labels.length),
                borderColor: '#111827',
                borderWidth: 5,
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                title: {
                    display: false
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        color: COLORS.muted,
                        padding: 15,
                        font: { size: 10, family: 'JetBrains Mono', weight: '600' },
                        usePointStyle: true,
                        pointStyle: 'rect'
                    }
                }
            },
            cutout: '80%'
        }
    });
}

/**
 * Handle form submission
 */
async function handleFormSubmit(e) {
    e.preventDefault();
    if (descriptionInput.value.trim() === '' || amountInput.value.trim() === '') return;

    const transactionData = {
        description: descriptionInput.value,
        amount: parseFloat(amountInput.value),
        type: typeInput.value,
        category: categoryInput.value,
        date: dateInput.value
    };

    try {
        const response = await fetch('/api/transactions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(transactionData)
        });

        if (response.ok) {
            const newTransaction = await response.json();
            transactions.unshift(newTransaction);

            renderList();
            updateTotals();
            updateChart();

            descriptionInput.value = '';
            amountInput.value = '';
            dateInput.valueAsDate = new Date();
        }
    } catch (error) {
        console.error('SYSTEM_POST_FAILURE:', error);
    }
}

async function removeTransaction(id) {
    try {
        const response = await fetch(`/api/transactions/${id}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            transactions = transactions.filter(t => t.id !== id);

            renderList();
            updateTotals();
            updateChart();
        }
    } catch (error) {
        console.error('SYSTEM_DELETE_FAILURE:', error);
    }
}

formEl.addEventListener('submit', handleFormSubmit);
window.removeTransaction = removeTransaction;
init();
